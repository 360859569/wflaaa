# CC-attack
 使用socks4 / 5代理攻击http服务器的脚本。

 删除了混合代理洪水，因为在我看来，洪水并不会提供更多性能

 新特性:
- [x] 快速套接字重用
- [x] 改进的CC模式
- [x] 随机客户端IP

 具体信息:
- [x] 使用Python3
- [x] 添加了更多智能选项
- [x] Http洪水
- [x] Http端口洪水
- [x] Http慢速攻击
- [x] 支持HTTPS
- [x] Socks4代理下载器
- [x] Socks4代理检查器
- [x] Socks5代理下载器
- [x] Socks5代理检查器
- [x] 随机Http发布数据
- [x] 随机Http标头
- [x] 随机Http Useragent
- [x] 移除了混合代理洪水
- [x] 添加了代理模式选择
- [x] 仍在改进的项目
## 安装

    pip3 install requests pysocks
    git clone https://github.com/kolbwang/cc-attack.git
    cd cc-attack

## 使用

    python3 cc.py
